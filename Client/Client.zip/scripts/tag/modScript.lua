extensions.load("vignetteShaderAPI") -- needs Stefan's vignette shader to work
extensions.load("tag")